# ML-Practical-2

1.  Implement neural network to recognise hand writen digits.
2. Implement K-means clustring.
3. Implement decision tree using ID3 algorithm.
4. Implement k- fold cross valudation technique.